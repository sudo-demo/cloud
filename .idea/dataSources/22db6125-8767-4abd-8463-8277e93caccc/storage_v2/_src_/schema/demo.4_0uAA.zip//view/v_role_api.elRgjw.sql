create definer = root@`%` view v_role_api as
select `sra`.`role_id`          AS `role_id`,
       `sra`.`role_api_id`      AS `role_api_id`,
       `sra`.`data_scope`       AS `data_scope`,
       `sra`.`operating_status` AS `operating_status`,
       `sra`.`data_key`         AS `data_key`,
       `sa`.`api_id`            AS `api_id`,
       `sa`.`parent_api_id`     AS `parent_api_id`,
       `sa`.`api_name`          AS `api_name`,
       `sa`.`is_button`         AS `is_button`,
       `sa`.`app_model`         AS `app_model`,
       `sa`.`action`            AS `action`
from (`demo`.`system_role_api` `sra` left join `demo`.`system_api` `sa` on ((`sra`.`api_id` = `sa`.`api_id`)));

-- comment on column v_role_api.role_id not supported: 角色id

-- comment on column v_role_api.role_api_id not supported: 主键

-- comment on column v_role_api.data_scope not supported: 数据范围

-- comment on column v_role_api.operating_status not supported: 操作状态

-- comment on column v_role_api.data_key not supported: 数据字段

-- comment on column v_role_api.api_id not supported: 主键

-- comment on column v_role_api.parent_api_id not supported: 父ID

-- comment on column v_role_api.api_name not supported: 接口名称

-- comment on column v_role_api.is_button not supported: 是否为按钮  0=>否，1=>是

-- comment on column v_role_api.app_model not supported: 后台 模块/控制器

-- comment on column v_role_api.action not supported: 后台 方法

